* Version: x.x.x
* Python: 2.7/3.4/3.5
* OS: osx/linux/win


### What was wrong?

Please include any of the following that are applicable:

* The code which produced the error
* The full output of the error


### How can it be fixed?

Fill this section in if you know how this could or should be fixed.
