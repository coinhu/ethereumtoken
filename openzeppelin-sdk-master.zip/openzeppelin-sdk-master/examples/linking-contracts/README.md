# OpenZeppelin SDK example: linking Ethereum Packages

This project demos how to link an Ethereum Package into your project. It uses `@openzeppelin/contracts-ethereum-package` to easily deploy an upgradeable ERC20. Head over to [our documentation](https://docs.zeppelinos.org/docs/linking.html) for a walkthrough on how this project was set up.