export const DEFAULT_TX_TIMEOUT = 750; // same as web3
export const DEFAULT_TX_BLOCK_TIMEOUT = 50; // same as web3
export const DEFAULT_EXPIRATION_TIMEOUT = 15 * 60; // 15 minutes
