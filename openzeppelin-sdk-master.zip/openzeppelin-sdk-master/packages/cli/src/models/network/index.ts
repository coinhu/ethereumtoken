import NetworkController from './NetworkController';

export default {
  NetworkController,
};
