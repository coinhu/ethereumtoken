import LocalController from './LocalController';

export default {
  LocalController,
};
