#!/bin/bash

# blueprint.networks.js
cp src/models/config/blueprint.networks.js lib/models/config/blueprint.networks.js
