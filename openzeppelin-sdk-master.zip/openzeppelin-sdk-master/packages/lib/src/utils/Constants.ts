export const IMPLEMENTATION_LABEL = 'eip1967.proxy.implementation';
export const DEPRECATED_IMPLEMENTATION_LABEL = 'org.zeppelinos.proxy.implementation';
export const ADMIN_LABEL = 'eip1967.proxy.admin';
export const DEPRECATED_ADMIN_LABEL = 'org.zeppelinos.proxy.admin';
