module.exports = {
  extends: [
      '../../../.eslintrc.base.js',
  ],
};